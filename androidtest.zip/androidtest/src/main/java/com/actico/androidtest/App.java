package com.actico.androidtest;

import test.TestRuleModel;
import test.test.ITestRequestData;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
    	ITestRequestData requestData = TestRuleModel.createTestRequestData();
		requestData.setInParameter("a", 5);
		TestRuleModel.performTest(requestData);
		Integer i = (Integer)requestData.getOutParameter("b");
        System.out.println( i );
    }
}
